---
description: 반복적 개선이 포함된 멀티 에이전트 코드 리뷰
argument-hint: "[scope] [--recent] [--domain AGENT] [--quick] [--create-tech-debt] [--resume]"
allowed-tools: Bash(git:*), Bash(node:*), Read, Write, Edit, Glob, Grep, Task, AskUserQuestion
---

# /audit-project - 멀티 에이전트 코드 리뷰

전문 AI 에이전트를 활용한 반복적 개선 포함 포괄적 코드 리뷰.

## 빠른 참조

| 단계 | 설명 | 상세 |
|------|------|------|
| 1 | 컨텍스트 & 에이전트 선택 | 이 파일 |
| 2 | 멀티 에이전트 리뷰 | `audit-project-agents.md` 참조 |
| 3-4 | 기술 부채 & 수정 | 이 파일 |
| 5-6 | 검증 & 반복 | 이 파일 |
| 7 | 완료 보고서 | 이 파일 |
| 8 | GitHub 이슈 | `audit-project-github.md` 참조 |

## 인수

$ARGUMENTS에서 파싱:
- **범위**: 리뷰할 경로 (기본값: `.`) 또는 `--recent` (최근 5개 커밋만)
- **--domain AGENT**: 특정 에이전트로만 리뷰 (예: `--domain security`)
- **--quick**: 단일 패스, 반복 없음 (빠른 피드백)
- **--create-tech-debt**: TECHNICAL_DEBT.md 강제 생성/업데이트
- **--resume**: 기존 리뷰 큐 파일에서 재개

### 재개 모드

`--resume`가 제공되면 플랫폼 상태 디렉토리의 가장 최근 리뷰 큐를 재사용합니다.
그렇지 않으면 새 큐 파일을 생성합니다. 큐 처리에 대해서는 `audit-project-agents.md`를 참조하세요.

## 1단계: 컨텍스트 수집

### 플랫폼 감지

```bash
# Get plugin root using Node.js helper
PLUGIN_ROOT=$(node -e "const { getPluginRoot } = require('@awesome-slash/lib/cross-platform'); const root = getPluginRoot('audit-project'); if (!root) { console.error('Error: Could not locate audit-project plugin root'); process.exit(1); } console.log(root);")
PLATFORM=$(node "$PLUGIN_ROOT/lib/platform/detect-platform.js")
TOOLS=$(node "$PLUGIN_ROOT/lib/platform/verify-tools.js")

PROJECT_TYPE=$(echo $PLATFORM | jq -r '.projectType')
PACKAGE_MGR=$(echo $PLATFORM | jq -r '.packageManager')

# Detect framework
FRAMEWORK="unknown"
if [ "$PROJECT_TYPE" = "nodejs" ]; then
  [ -n "$(jq -e '.dependencies.react' package.json 2>/dev/null)" ] && FRAMEWORK="react"
  [ -n "$(jq -e '.dependencies.express' package.json 2>/dev/null)" ] && FRAMEWORK="express"
elif [ "$PROJECT_TYPE" = "python" ]; then
  grep -q "django" requirements.txt 2>/dev/null && FRAMEWORK="django"
  grep -q "fastapi" requirements.txt 2>/dev/null && FRAMEWORK="fastapi"
fi

RESUME_MODE=$([ "${ARGUMENTS}" != "${ARGUMENTS%--resume*}" ] && echo "true" || echo "false")
```

### 프로젝트 분석

```bash
FILE_COUNT=$(git ls-files | wc -l)
TEST_FILES=$(git ls-files | grep -E '(test|spec)\.' | wc -l)
HAS_TESTS=$( [ "$TEST_FILES" -gt 0 ] && echo "true" || echo "false" )
HAS_DB=$(grep -rq -E "(Sequelize|Prisma|TypeORM)" . 2>/dev/null && echo "true" || echo "false")
HAS_API=$(grep -rq -E "(express|fastify|@nestjs)" . 2>/dev/null && echo "true" || echo "false")
HAS_FRONTEND=$( [ "$(git ls-files | grep -E '\.(tsx|jsx|vue|svelte)$' | wc -l)" -gt 0 ] && echo "true" || echo "false" )
HAS_BACKEND=$(grep -rq -E "(express|fastify|@nestjs|koa|hapi)" . 2>/dev/null && echo "true" || echo "false")
if [ -d ".github/workflows" ] || [ -f ".gitlab-ci.yml" ] || [ -f ".circleci/config.yml" ] || \
  [ -f "Jenkinsfile" ] || [ -f ".travis.yml" ] || [ -f "azure-pipelines.yml" ] || \
  [ -f "bitbucket-pipelines.yml" ]; then
  HAS_CICD="true"
else
  HAS_CICD="false"
fi
```

### 에이전트 선택

**항상 활성:**
- `code-quality-reviewer`: 코드 품질, 에러 처리, 유지보수성
- `security-expert`: 보안 취약점, 인증, 입력 검증
- `performance-engineer`: 성능 병목, 알고리즘, 메모리
- `test-quality-guardian`: 테스트 커버리지와 품질 (누락된 테스트 보고)

**조건부:**
- `architecture-reviewer`: 디자인 패턴 (`FILE_COUNT > 50`인 경우)
- `database-specialist`: 쿼리 최적화 (`HAS_DB=true`인 경우)
- `api-designer`: REST 모범 사례 (`HAS_API=true`인 경우)
- `frontend-specialist`: 컴포넌트 설계 (`HAS_FRONTEND=true`인 경우)
- `backend-specialist`: 서비스 및 도메인 로직 (`HAS_BACKEND=true`인 경우)
- `devops-reviewer`: CI/CD 설정 (`HAS_CICD=true`인 경우)

## 2단계: 멀티 에이전트 리뷰

상세한 에이전트 조정은 `audit-project-agents.md`를 참조하세요.

**리뷰 큐:** 플랫폼 상태 디렉토리의 임시 큐 파일에 발견사항을 기록하고 모든 이슈가 해결될 때까지 업데이트합니다. 큐가 비면 파일을 제거합니다.

### 발견사항 형식 (필수)

모든 발견사항에 반드시 포함:
- **파일:줄**: 정확한 위치 (예: `src/auth/session.ts:42`)
- **심각도**: critical | high | medium | low
- **카테고리**: 에이전트 도메인에서
- **설명**: 무엇이 잘못되었고 왜 그런지
- **코드 인용**: 문제를 보여주는 1-3줄
- **제안 수정**: 구체적 해결 방법
- **노력**: small | medium | large

### 발견사항 예시

```markdown
### Finding: Unsafe SQL Query
**Agent**: security-expert
**File**: src/api/users.ts:87
**Severity**: critical
**Code**:
```typescript
const query = `SELECT * FROM users WHERE id = ${userId}`;
```
**Fix**: Use parameterized queries.
**Effort**: small
```

## Phase 3: Tech Debt Documentation

If TECHNICAL_DEBT.md exists or `--create-tech-debt`:

```markdown
# Technical Debt

Last updated: $(date -I)

## Summary
**Total Issues**: X | Critical: Y | High: Z | Medium: A | Low: B

## Critical Issues
[Grouped by severity with file:line, description, fix, effort]

## Progress Tracking
- [ ] Issue 1
- [ ] Issue 2
```

## Phase 4: Automated Fixes

### Fix Strategy

1. **Auto-fixable** (lint, formatting): Apply directly
2. **Manual fix** (code logic): Implement suggested fix
3. **Design decision required**: Flag as blocked and report to user
4. **False positive**: Mark and remove from review queue

### Fix Order

1. Critical severity first
2. Then high → medium → low
3. Then by effort (small → large)
4. Then batch by file

## Phase 5: Verification

```bash
# Run tests
[ -n "$TEST_CMD" ] && $TEST_CMD
TEST_STATUS=$?

# Run linter
[ -n "$LINT_CMD" ] && $LINT_CMD
LINT_STATUS=$?

# Run build
[ -n "$BUILD_CMD" ] && $BUILD_CMD
BUILD_STATUS=$?

# Overall status
VERIFICATION_PASSED=$([ $TEST_STATUS -eq 0 ] && [ $LINT_STATUS -eq 0 ] && [ $BUILD_STATUS -eq 0 ] && echo "true" || echo "false")
```

### Handle Failures

If verification fails:
1. Review recent changes (`git diff`)
2. Identify breaking fix
3. Rollback: `git restore <file>`
4. Document as "fix caused regression"

## Phase 6: Iteration

```javascript
const initialReview = /* results from Phase 2 review */;
const initialIssues = Array.isArray(initialReview?.issues) ? initialReview.issues : [];
let iteration = 1;
let remainingIssues = initialIssues;

while (remainingIssues.length > 0) {
  const fixResult = applyFixes(remainingIssues);

  const verifyResult = runVerification();
  if (!verifyResult.passed) {
    rollbackFailed(fixResult);
  }

  const reReviewResult = reReview(fixResult.changedFiles);
  remainingIssues = reReviewResult.issues;

  if (remainingIssues.length === 0) {
    console.log("[OK] Zero issues remaining!");
    break;
  }

  iteration++;
}
```

### Quick Mode

If `--quick` flag: Single pass, findings only, no fixes.

## Phase 6.5: Decision Gate (User)

After each iteration (or after re-review if issues remain), report the queue state and ask the user what to do next.

```javascript
const openCount = remainingIssues.length;
console.log(`Open issues: ${openCount}`);
console.log(`Queue file: ${reviewQueuePath}`); // set in Phase 2 (audit-project-agents)

const decision = await AskUserQuestion({
  questions: [{
    header: "Audit Decision",
    question: "Review queue still open. What next?",
    options: [
      { label: "Continue review", description: "Run another iteration" },
      { label: "Create issues", description: "Stop and create issues" },
      { label: "Update tech debt", description: "Stop and update TECHNICAL_DEBT.md" },
      { label: "Leave queue", description: "Stop and keep queue for resume" }
    ],
    multiSelect: false
  }]
});

const choice = decision[0];
if (choice === 'Continue review') {
  // continue loop
} else if (choice === 'Create issues') {
  // Create issues and remove queue file
} else if (choice === 'Update tech debt') {
  // Update TECHNICAL_DEBT.md and remove queue file
} else if (choice === 'Leave queue') {
  // Leave queue file for --resume
  break;
}
```

## Phase 7: Completion Report

```markdown
# Project Review Complete

**Scope**: ${SCOPE} | **Framework**: ${FRAMEWORK}
**Iterations**: ${iteration} | **Duration**: ${duration}

## Summary
**Issues Found**: ${initialCount}
**Issues Fixed**: ${fixedCount}
**Remaining**: ${remainingCount}

## By Severity
- Critical: ${criticalFound} → ${criticalRemaining}
- High: ${highFound} → ${highRemaining}
- Medium: ${mediumFound} → ${mediumRemaining}
- Low: ${lowFound} → ${lowRemaining}

## Verification
- Tests: [OK]/[FAIL]
- Linter: [OK]/[FAIL]
- Build: [OK]/[FAIL]

## Files Changed
${FILE_COUNT} files modified

## Remaining Issues
[List of issues needing attention]
```

## Phase 8: GitHub Issue Creation

See `audit-project-github.md` for:
- Creating GitHub issues for deferred items
- Security issue handling (no public issues)
- TECHNICAL_DEBT.md cleanup

## Error Handling

### No Framework Detected
```
Framework detection failed, using generic patterns.
```

### No Tests Available
```
No test suite detected. Skipping test-quality-guardian.
```

### All Agents Failed
```
ERROR: All review agents failed.
Try: --recent or specific path for smaller scope.
```

## Usage Examples

```bash
/audit-project                    # Full review
/audit-project --recent           # Last 5 commits only
/audit-project src/api            # Specific path
/audit-project --domain security  # Security audit only
/audit-project --quick            # Fast feedback, no fixes
/audit-project --create-tech-debt # Force tech debt file
```

## Success Criteria

- [OK] All agents completed review
- [OK] Evidence-based findings (file:line provided)
- [OK] Critical issues fixed or documented
- [OK] Verification passes
- [OK] TECHNICAL_DEBT.md updated (if enabled)

Begin Phase 1 now.
