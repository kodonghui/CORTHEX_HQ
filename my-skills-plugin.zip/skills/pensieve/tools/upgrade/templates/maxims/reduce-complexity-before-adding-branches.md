---
id: reduce-complexity-before-adding-branches
type: maxim
title: 분기를 추가하기 전에 복잡도 줄이기
status: active
created: 2026-02-11
updated: 2026-02-11
tags: [pensieve, maxim]
---

# 분기를 추가하기 전에 복잡도 줄이기

## 한 줄 결론
> 로직이 읽기 어려워지면, 먼저 구조를 단순화하고 필요한 경우에만 나중에 분기합니다.

## 인용구
"3단계 이상의 들여쓰기가 필요하다면, 어차피 망한 것이니 프로그램을 고치세요."

## 지침
- 대형 함수를 책임별로 분할합니다.
- 제어 흐름을 얕고 명시적으로 유지합니다.
- 설명적 주석보다 명확한 네이밍을 선호합니다.

## 경계
- 작고 국소적인 분기는 가독성을 향상시킬 때 허용됩니다.

## 컨텍스트 링크 (권장)
- Based on: [[prefer-pragmatic-solutions-over-theoretical-completeness]]
- Leads to: [[eliminate-special-cases-by-redesigning-data-flow]]
- Related: [[knowledge/taste-review/content]]
