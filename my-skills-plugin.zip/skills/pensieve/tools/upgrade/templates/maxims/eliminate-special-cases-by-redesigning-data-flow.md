---
id: eliminate-special-cases-by-redesigning-data-flow
type: maxim
title: 데이터 흐름 재설계를 통해 특수 케이스 제거
status: active
created: 2026-02-11
updated: 2026-02-11
tags: [pensieve, maxim]
---

# 데이터 흐름 재설계를 통해 특수 케이스 제거

## 한 줄 결론
> 엣지 케이스가 기본 경로가 되도록 데이터 형태나 흐름을 변경하는 것을 선호합니다.

## 인용구
"때때로 문제를 다른 방식으로 바라보고 특수 케이스가 사라져 일반 케이스가 되도록 다시 작성할 수 있습니다."

## 지침
- 일회성 입력을 패치하기 위해서만 존재하는 분기를 제거합니다.
- 하위 단계에 조건문을 추가하기 전에 상위 계약을 수정합니다.
- 데이터 구조를 먼저 리팩토링한 후, 코드 경로를 단순화합니다.

## 경계
- 분기를 제거했을 때 사용자에게 보이는 동작이 깨진다면, 마이그레이션으로 취급하고 먼저 검토합니다.

## 컨텍스트 링크 (권장)
- Based on: [[knowledge/taste-review/content]]
- Leads to: [[preserve-user-visible-behavior-as-a-hard-rule]]
- Related: [[reduce-complexity-before-adding-branches]]
