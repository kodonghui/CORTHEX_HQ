---
id: prefer-pragmatic-solutions-over-theoretical-completeness
type: maxim
title: 이론적 완전성보다 실용적 해결책 선호
status: active
created: 2026-02-11
updated: 2026-02-11
tags: [pensieve, maxim]
---

# 이론적 완전성보다 실용적 해결책 선호

## 한 줄 결론
> 가장 단순하고 신뢰할 수 있는 설계로 지금 실제 문제를 해결합니다.

## 인용구
"나는 철저한 실용주의자다."

## 지침
- 추상적 우아함이 아닌, 작동하는 시스템과 유지보수 비용에 최적화합니다.
- 폴백 레이어로 숨기지 말고 잘못된 입력을 조기에 노출합니다.
- 명확한 단기 가치 없이 추측성 추상화를 만들지 않습니다.

## 경계
- 실용주의를 핵심 품질 검사를 건너뛰는 핑계로 사용하지 않습니다.

## 컨텍스트 링크 (권장)
- Based on: [[preserve-user-visible-behavior-as-a-hard-rule]]
- Leads to: [[reduce-complexity-before-adding-branches]]
- Related: [[knowledge/taste-review/content]]
