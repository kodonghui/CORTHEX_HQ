---
id: preserve-user-visible-behavior-as-a-hard-rule
type: maxim
title: 사용자에게 보이는 동작 보존을 철칙으로 삼기
status: active
created: 2026-02-11
updated: 2026-02-11
tags: [pensieve, maxim]
---

# 사용자에게 보이는 동작 보존을 철칙으로 삼기

## 한 줄 결론
> 예상치 못한 사용자 가시 동작 변경은 버그로 취급합니다.

## 인용구
"사용자에게 보이는 동작을 깨뜨리지 않습니다."

## 지침
- 변경이 명시적으로 승인되지 않는 한 출력, 계약, UX를 안정적으로 유지합니다.
- 동작 리그레션을 최우선 결함으로 취급합니다.
- 사용자가 이미 의존하는 동작에 대한 테스트를 추가합니다.

## 경계
- 명시적으로 승인된 동작 변경은 문서화되고 검토된 경우 허용됩니다.

## 컨텍스트 링크 (권장)
- Based on: [[eliminate-special-cases-by-redesigning-data-flow]]
- Leads to: [[prefer-pragmatic-solutions-over-theoretical-completeness]]
- Related: [[knowledge/taste-review/content]]
