# 핸드오프

Claude 세션 간 연속성을 위한 구조화된 세션 핸드오프 문서를 생성합니다.

## 문제점

Claude 세션은 유지되지 않습니다. 세션을 종료하고 새로 시작하면 다음을 잃게 됩니다:

- 내린 결정과 그 이유
- 구축하던 것의 맥락
- 작업을 중단한 지점
- 확립했던 세부사항과 제약 조건

처음부터 다시 시작하면 모든 것을 다시 설명해야 하며, 번역 과정에서 중요한 맥락을 잃는 경우가 많습니다.

## 해결책

`/handoff` 스킬은 미래 세션이 중단한 지점에서 바로 이어갈 수 있도록 필요한 모든 것을 캡처하는 구조화된 문서를 생성합니다:

- 현재 작업 상태 및 진행률
- 근거와 함께 내린 결정 사항
- 의도가 포함된 코드 변경 내역
- 미해결 질문 및 차단 요소
- 확립하는 데 시간이 걸렸던 사용자 제공 맥락
- 명확한 다음 단계

## 사용 시점

- **작업 세션 종료 시** — 로그아웃 전 상태 캡처
- **휴식 전** — 작업 중이라도 맥락을 잃을 수 있는 경우
- **프로젝트 전환 시** — 컨텍스트 스위칭 전 상태 저장
- **알려진 리셋 전** — 압축이나 리셋이 예정된 경우

## 작동 방식

**1단계:** Claude가 현재 세션 상태를 평가

**2단계:** 캡처할 내용을 질문:

> "핸드오프 문서를 작성하겠습니다. 반드시 캡처하고 싶은 내용이 있나요?"

**3단계:** 구조화된 핸드오프 문서 생성

**4단계:** `.claude/handoffs/[날짜]-[설명].md`에 저장

## 핸드오프 문서 구조

```markdown
# Session Handoff: [Brief Description]

**Date:** 2025-01-15
**Project:** /path/to/project
**Session Duration:** ~2 hours

## Current State

Task, phase, and progress

## What We Did

2-3 sentence summary

## Decisions Made

- Decision — Rationale
- Decision — Rationale

## Code Changes

Files modified with what and why

## Open Questions

Unresolved items needing attention

## Context to Remember

Important background, constraints, preferences

## Next Steps

Clear, actionable items to resume with

## Files to Review on Resume

Key files to read to get back up to speed
```

## 핸드오프 문서 사용법

새 세션을 시작할 때:

1. 세션 시작 시 핸드오프 파일을 공유
2. "이 핸드오프에서 이어서 작업해줘"라고 말하고 파일을 붙여넣거나 참조
3. 지원되는 경우 @ 멘션 사용

핸드오프를 통해 Claude가 장황한 재설명 없이 바로 작업에 착수할 수 있습니다.

## 관련: 압축 훅

세션 내 연속성(세션이 계속되지만 컨텍스트가 압축되는 경우)에 대해서는 [compaction-hook](../compaction-hook/)을 참조하세요. 압축 중 보존되는 내용을 자동으로 개선합니다.

| 핸드오프 스킬 | 압축 훅 |
| ------------ | ------- |
| 세션 간 연속성 | 세션 내 연속성 |
| 수동, 명시적 | 자동, 무음 |
| 보관할 파일 생성 | 내부 상태에 영향 |
| 전체 맥락 캡처 | 보존 우선순위 |

완전한 커버리지를 위해 둘 다 사용하세요.
