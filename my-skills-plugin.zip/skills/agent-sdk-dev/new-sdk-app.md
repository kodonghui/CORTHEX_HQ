---
description: 새로운 Claude Agent SDK 애플리케이션을 생성하고 설정합니다
argument-hint: [project-name]
---

사용자가 새로운 Claude Agent SDK 애플리케이션을 만들 수 있도록 도와주는 작업입니다. 다음 단계를 주의깊게 따르세요:

## 참조 문서

시작하기 전에 공식 문서를 검토하여 정확하고 최신 안내를 제공하세요. WebFetch를 사용하여 다음 페이지를 읽으세요:

1. **개요부터 시작**: https://docs.claude.com/en/api/agent-sdk/overview
2. **사용자의 언어 선택에 따라 해당 SDK 레퍼런스 읽기**:
   - TypeScript: https://docs.claude.com/en/api/agent-sdk/typescript
   - Python: https://docs.claude.com/en/api/agent-sdk/python
3. **개요에서 언급된 관련 가이드 읽기**:
   - 스트리밍 vs 단일 모드
   - 권한
   - 커스텀 도구
   - MCP 통합
   - 서브에이전트
   - 세션
   - 사용자의 필요에 따른 기타 관련 가이드

**중요**: 항상 최신 버전의 패키지를 확인하고 사용하세요. 설치 전에 WebSearch 또는 WebFetch로 현재 버전을 확인하세요.

## 요구사항 수집

중요: 질문을 한 번에 하나씩 하세요. 다음 질문을 하기 전에 사용자의 응답을 기다리세요. 이렇게 하면 사용자가 더 쉽게 응답할 수 있습니다.

다음 순서로 질문하세요 (사용자가 이미 인수를 통해 제공한 항목은 건너뜁니다):

1. **언어** (첫 번째 질문): "TypeScript와 Python 중 어떤 것을 사용하시겠습니까?"

   - 계속하기 전에 응답을 기다립니다

2. **프로젝트 이름** (두 번째 질문): "프로젝트 이름을 무엇으로 하시겠습니까?"

   - $ARGUMENTS가 제공된 경우 프로젝트 이름으로 사용하고 이 질문을 건너뜁니다
   - 계속하기 전에 응답을 기다립니다

3. **에이전트 유형** (세 번째 질문, #2가 충분히 상세하면 건너뜁니다): "어떤 종류의 에이전트를 만드시나요? 예시:

   - 코딩 에이전트 (SRE, 보안 리뷰, 코드 리뷰)
   - 비즈니스 에이전트 (고객 지원, 콘텐츠 생성)
   - 커스텀 에이전트 (사용 사례를 설명해주세요)"
   - 계속하기 전에 응답을 기다립니다

4. **시작점** (네 번째 질문): "어떤 것을 원하시나요:

   - 시작을 위한 최소한의 'Hello World' 예제
   - 일반적인 기능이 포함된 기본 에이전트
   - 사용 사례에 맞는 특정 예제"
   - 계속하기 전에 응답을 기다립니다

5. **도구 선택** (다섯 번째 질문): 사용할 도구를 사용자에게 알리고, 원하는 도구인지 확인합니다 (예: npm 대신 pnpm이나 bun을 선호할 수 있음). 요구사항을 실행할 때 사용자의 선호도를 존중하세요.

모든 질문에 답변한 후 설정 계획을 작성합니다.

## 설정 계획

사용자의 답변을 바탕으로 다음을 포함하는 계획을 작성합니다:

1. **프로젝트 초기화**:

   - 프로젝트 디렉토리 생성 (존재하지 않는 경우)
   - 패키지 매니저 초기화:
     - TypeScript: `npm init -y` 및 type: "module"과 스크립트가 포함된 `package.json` 설정 ("typecheck" 스크립트 포함)
     - Python: `requirements.txt` 생성 또는 `poetry init` 사용
   - 필요한 설정 파일 추가:
     - TypeScript: SDK에 적합한 설정이 포함된 `tsconfig.json` 생성
     - Python: 필요한 경우 선택적으로 설정 파일 생성

2. **최신 버전 확인**:

   - 설치하기 전에 WebSearch를 사용하거나 npm/PyPI에서 최신 버전 확인
   - TypeScript: https://www.npmjs.com/package/@anthropic-ai/claude-agent-sdk 확인
   - Python: https://pypi.org/project/claude-agent-sdk/ 확인
   - 설치할 버전을 사용자에게 알림

3. **SDK 설치**:

   - TypeScript: `npm install @anthropic-ai/claude-agent-sdk@latest` (또는 최신 버전 지정)
   - Python: `pip install claude-agent-sdk` (pip은 기본적으로 최신 버전 설치)
   - 설치 후 설치된 버전 확인:
     - TypeScript: package.json 확인 또는 `npm list @anthropic-ai/claude-agent-sdk` 실행
     - Python: `pip show claude-agent-sdk` 실행

4. **시작 파일 생성**:

   - TypeScript: 기본 쿼리 예제가 포함된 `index.ts` 또는 `src/index.ts` 생성
   - Python: 기본 쿼리 예제가 포함된 `main.py` 생성
   - 적절한 import와 기본 에러 처리 포함
   - 최신 SDK 버전의 최신 구문 및 패턴 사용

5. **환경 설정**:

   - `ANTHROPIC_API_KEY=your_api_key_here`가 포함된 `.env.example` 파일 생성
   - `.gitignore`에 `.env` 추가
   - https://console.anthropic.com/ 에서 API 키를 받는 방법 설명

6. **선택사항: .claude 디렉토리 구조 생성**:
   - 에이전트, 명령어, 설정을 위한 `.claude/` 디렉토리 생성 제안
   - 예제 서브에이전트나 슬래시 명령이 필요한지 확인

## 구현

요구사항 수집 및 계획에 대한 사용자 확인 후:

1. WebSearch 또는 WebFetch를 사용하여 최신 패키지 버전 확인
2. 설정 단계 실행
3. 필요한 모든 파일 생성
4. 의존성 설치 (항상 최신 안정 버전 사용)
5. 설치된 버전 확인 및 사용자에게 알림
6. 에이전트 유형에 맞는 작동하는 예제 생성
7. 각 부분이 무엇을 하는지 설명하는 유용한 주석을 코드에 추가
8. **완료 전에 코드가 작동하는지 확인**:
   - TypeScript:
     - `npx tsc --noEmit`을 실행하여 타입 오류 확인
     - 타입이 완전히 통과할 때까지 모든 타입 오류 수정
     - import와 타입이 올바른지 확인
     - 타입 검사가 오류 없이 통과할 때만 진행
   - Python:
     - import가 올바른지 확인
     - 기본 구문 오류 확인
   - **코드 검증이 성공할 때까지 설정이 완료된 것으로 간주하지 마세요**

## 검증

모든 파일이 생성되고 의존성이 설치된 후, 적절한 검증 에이전트를 사용하여 Agent SDK 애플리케이션이 올바르게 구성되고 사용 준비가 되었는지 검증합니다:

1. **TypeScript 프로젝트**: **agent-sdk-verifier-ts** 에이전트를 실행하여 설정 검증
2. **Python 프로젝트**: **agent-sdk-verifier-py** 에이전트를 실행하여 설정 검증
3. 에이전트가 SDK 사용법, 구성, 기능, 공식 문서 준수 여부를 확인
4. 검증 보고서를 검토하고 문제 해결

## 시작 가이드

설정이 완료되고 검증된 후 사용자에게 다음을 제공합니다:

1. **다음 단계**:

   - API 키 설정 방법
   - 에이전트 실행 방법:
     - TypeScript: `npm start` 또는 `node --loader ts-node/esm index.ts`
     - Python: `python main.py`

2. **유용한 리소스**:

   - TypeScript SDK 레퍼런스 링크: https://docs.claude.com/en/api/agent-sdk/typescript
   - Python SDK 레퍼런스 링크: https://docs.claude.com/en/api/agent-sdk/python
   - 핵심 개념 설명: 시스템 프롬프트, 권한, 도구, MCP 서버

3. **일반적인 다음 단계**:
   - 시스템 프롬프트 커스터마이즈 방법
   - MCP를 통한 커스텀 도구 추가 방법
   - 권한 설정 방법
   - 서브에이전트 생성 방법

## 중요 참고사항

- **항상 최신 버전 사용**: 패키지를 설치하기 전에 WebSearch를 사용하거나 npm/PyPI에서 직접 최신 버전을 확인하세요
- **코드가 올바르게 실행되는지 확인**:
  - TypeScript: `npx tsc --noEmit`을 실행하고 완료 전에 모든 타입 오류를 수정하세요
  - Python: 구문과 import가 올바른지 확인하세요
  - 코드가 검증을 통과할 때까지 작업이 완료된 것으로 간주하지 마세요
- 설치 후 설치된 버전을 확인하고 사용자에게 알리세요
- 버전별 요구사항(Node.js 버전, Python 버전 등)에 대한 공식 문서를 확인하세요
- 생성하기 전에 디렉토리/파일이 이미 존재하는지 항상 확인하세요
- 사용자가 선호하는 패키지 매니저를 사용하세요 (TypeScript: npm, yarn, pnpm / Python: pip, poetry)
- 모든 코드 예제가 작동하고 적절한 에러 처리를 포함하는지 확인하세요
- 최신 SDK 버전과 호환되는 최신 구문 및 패턴을 사용하세요
- 경험을 인터랙티브하고 교육적으로 만드세요
- **질문은 한 번에 하나씩** - 하나의 응답에 여러 질문을 하지 마세요

첫 번째 요구사항 질문만 하세요. 다음 질문으로 넘어가기 전에 사용자의 답변을 기다리세요.
