# 인용 표준

비소설 서적을 위한 시카고 매뉴얼 오브 스타일 인용 형식. 완전한 서지 정보와 주석 안내를 포함합니다.

---

## 왜 시카고 스타일인가

시카고는 비소설 서적 출판의 표준입니다. 리서치 단계부터 사용하면:

- 인용이 원고에 바로 사용 가능
- 팩트체커가 출처를 검증 가능
- 참고문헌을 직접 편집 가능
- 처음부터 전문적 신뢰성 확보

---

## 핵심 원칙: 완전한 정보

모든 인용에는 누군가가 다음을 할 수 있을 만큼 충분한 정보가 포함되어야 합니다:

1. 출처를 찾을 수 있음
2. 주장을 검증할 수 있음
3. 출처의 신뢰성을 평가할 수 있음

의심스러우면 정보를 덜 넣기보다 더 넣으세요.

---

## 출처 유형별 인용 형식

### 서적

**단일 저자:**
Last, First. _Title: Subtitle_. Place: Publisher, Year.

> Smith, John. _The Art of Thinking: A Guide to Critical Reasoning_. New York: Academic Press, 2020.

**2-3인 저자:**
Last, First, and First Last. _Title_. Place: Publisher, Year.

> Smith, John, and Jane Doe. _Collaborative Learning_. Chicago: University of Chicago Press, 2019.

**4인 이상 저자:**
Last, First, et al. _Title_. Place: Publisher, Year.

> Smith, John, et al. _Comprehensive Research Methods_. Boston: Beacon Press, 2021.

**편집자가 저자인 경우:**
Last, First, ed. _Title_. Place: Publisher, Year.

> Johnson, Mary, ed. _Essays on Modern Education_. Cambridge: Harvard University Press, 2018.

**편집된 볼륨 내 챕터:**
Last, First. "Chapter Title." In _Book Title_, edited by First Last, pages. Place: Publisher, Year.

> Williams, Robert. "The Future of Work." In _Economic Transformations_, edited by Sarah Chen, 45-72. New York: Oxford University Press, 2022.

**번역서:**
Last, First. _Title_. Translated by First Last. Place: Publisher, Year. Originally published as _Original Title_ (Place: Publisher, Year).

> Luhmann, Niklas. _Theory of Society_. Translated by Rhodes Barrett. Stanford: Stanford University Press, 2012. Originally published as _Die Gesellschaft der Gesellschaft_ (Frankfurt: Suhrkamp, 1997).

---

### 학술지 논문

**인쇄 학술지:**
Last, First. "Article Title." _Journal Name_ Volume, no. Issue (Year): Pages.

> Mueller, Pam A., and Daniel M. Oppenheimer. "The Pen Is Mightier Than the Keyboard." _Psychological Science_ 25, no. 6 (2014): 1159-1168.

**DOI가 있는 온라인 학술지:**
Last, First. "Article Title." _Journal Name_ Volume, no. Issue (Year): Pages. DOI.

> Schmidt, Johannes F.K. "Niklas Luhmann's Card Index." _Sociologica_ 12, no. 1 (2018): 53-60. https://doi.org/10.6092/issn.1971-8853/8350.

**URL이 있는 온라인 학술지:**
Last, First. "Article Title." _Journal Name_ Volume, no. Issue (Year): Pages. URL.

---

### 온라인 출처

**저자가 있는 웹사이트:**
Last, First. "Page Title." Website Name. Date. URL.

> Newport, Cal. "Deep Work in the Age of Distraction." Cal Newport Blog. March 15, 2023. https://calnewport.com/deep-work-distraction/.

**저자가 없는 웹사이트:**
Organization or Website Name. "Page Title." Date. URL.

> Pew Research Center. "The State of Remote Work in 2023." June 10, 2023. https://pewresearch.org/remote-work-2023/.

**온라인 보고서:**
Organization. _Report Title_. Place: Publisher, Year. URL.

> McKinsey Global Institute. _The Future of Work After COVID-19_. New York: McKinsey & Company, 2021. https://mckinsey.com/future-of-work.

---

### 뉴스 기사

**인쇄:**
Last, First. "Article Title." _Publication Name_, Date.

> Thompson, Derek. "The Myth of Productivity." _The Atlantic_, September 2022.

**온라인:**
Last, First. "Article Title." _Publication Name_, Date. URL.

> Manjoo, Farhad. "The Case for Working Less." _New York Times_, April 5, 2023. https://nytimes.com/working-less-case.

---

### 정부 및 기관 문서

**정부 보고서:**
Government Body. _Report Title_. Document Number. Place: Publisher, Year. URL.

> U.S. Department of Labor. _Future of Work Report_. Report No. 2023-04. Washington, DC: Government Printing Office, 2023. https://dol.gov/future-work.

**의회 증언:**
Last, First. "Title of Testimony." Testimony before Committee Name, Congress, Session. Date. URL.

---

### 학위 논문

Last, First. "Title." PhD diss., University, Year. Database Name (Identifier).

> Johnson, Maria. "Knowledge Management in Academic Settings." PhD diss., Stanford University, 2020. ProQuest (12345678).

---

### 학회 논문

Last, First. "Paper Title." Paper presented at Conference Name, Location, Date.

> Chen, Wei. "AI and Knowledge Work." Paper presented at the Annual Meeting of the Academy of Management, Boston, MA, August 2023.

---

### 인터뷰 및 개인 커뮤니케이션

출판된 인터뷰:
Last, First. Interview by First Last. Publication, Date. URL.

미출판/개인:
Last, First. Interview by/Email to author. Date.

---

## 필수 요소 체크리스트

모든 인용에 대해 다음을 확인합니다:

### 서적

- [ ] 저자 전체 이름
- [ ] 완전한 제목 및 부제
- [ ] 출판 도시
- [ ] 출판사 이름
- [ ] 출판 연도
- [ ] 페이지 번호 (특정 구절 인용 시)

### 논문

- [ ] 저자 전체 이름
- [ ] 논문 제목
- [ ] 학술지/출판물 이름
- [ ] 볼륨 및 이슈 번호
- [ ] 연도
- [ ] 페이지 범위
- [ ] DOI 또는 URL (온라인의 경우)

### 온라인 출처

- [ ] 저자 또는 조직
- [ ] 페이지/기사 제목
- [ ] 웹사이트 이름
- [ ] 출판 또는 접근 날짜
- [ ] URL

---

## 주석 형식

리서치 목적으로 출처의 가치를 설명하는 간략한 주석을 포함합니다:

**형식:**
[완전한 인용]
_주석: [이 출처가 무엇을 기여하고 그 신뢰성에 대한 1-2 문장]_

**예시:**
Schmidt, Johannes F.K. "Niklas Luhmann's Card Index: The Fabrication of Serendipity." _Sociologica_ 12, no. 1 (2018): 53-60. https://doi.org/10.6092/issn.1971-8853/8350.
_주석: 직접 접근 권한을 가진 연구자에 의한 루만의 실제 아카이브에 대한 1차 학술 분석. 90,000장 카드 시스템과 그 조직 원칙에 대한 구체적 세부 사항을 제공합니다. 높은 신뢰도—동료 심사를 거치고 직접 조사에 기반합니다._

---

## 검증 플래그

LLM 리서치에서 출처를 인용할 때 검증 플래그를 추가합니다:

**[Retrieved]** — 리서치 중 출처를 실제로 접근함
**[Training]** — 학습 데이터에서 알고 있음, 새로 검색하지 않음
**[Unverified]** — 인용이 제공되었지만 독립적으로 확인되지 않음
**[Verified]** — 인용을 확인하고 정확함을 검증함

**예시:**
Mueller, Pam A., and Daniel M. Oppenheimer. "The Pen Is Mightier Than the Keyboard." _Psychological Science_ 25, no. 6 (2014): 1159-1168. [Retrieved] [Verified]

---

## 흔한 실수 방지

### 불완전한 정보

❌ Smith, _Thinking Better_ (2020).
✅ Smith, John. _Thinking Better: A Guide to Clear Reasoning_. Boston: Beacon Press, 2020.

### 페이지 번호 누락

특정 주장을 인용할 때 페이지를 포함합니다:
✅ Smith, John. _Thinking Better_. Boston: Beacon Press, 2020, 45-47.

### 날짜 없는 URL

❌ https://example.com/article
✅ Example Organization. "Article Title." Accessed January 15, 2024. https://example.com/article.

### 일관성 없는 형식

하나의 형식 (notes-bibliography 또는 author-date)을 선택하고 전체에 걸쳐 일관되게 사용합니다.

### 인정 없는 2차 출처

다른 출처에서 참조된 것을 인용하는 경우:
✅ Luhmann, Niklas. "Kommunikation mit Zettelkästen." In _Öffentliche Meinung_, edited by H. Baier, 222-228. Opladen: Westdeutscher Verlag, 1981. Quoted in Schmidt, "Luhmann's Card Index," 55.

---

## 인용 정리

### 리서치 단계용

인용을 다음으로 그룹화합니다:

1. 지원하는 챕터
2. 제공하는 증거 유형
3. 품질 등급 (1차, 2차 등)

### 참고문헌용

저자 성으로 알파벳순 정리. 동일 저자의 여러 저작은 시간순으로 배열합니다.

---

## 빠른 참조: 필수 요소

| 출처 유형  | 필수 요소                                          |
| ---------- | -------------------------------------------------- |
| 서적       | 저자, 제목, 장소, 출판사, 연도                      |
| 학술지     | 저자, 제목, 학술지, 볼륨, 이슈, 연도, 페이지, DOI   |
| 웹사이트   | 저자/조직, 제목, 사이트 이름, 날짜, URL              |
| 뉴스       | 저자, 제목, 출판물, 날짜, URL                       |
| 보고서     | 조직, 제목, 장소, 출판사, 연도, URL                  |

---

_리서치 프롬프트와 검증에서 모든 인용에 이 표준을 사용하세요. 지금 일관된 인용 관행을 갖추면 팩트체킹과 제작 중에 상당한 시간을 절약합니다._
