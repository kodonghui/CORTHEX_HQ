# Amazon 필드 가이드

경쟁자 분석을 위한 데이터 필드를 찾는 방법.

## 빠른 참조

| 필드         | 의미                       | 찾는 위치                      |
| ------------ | -------------------------- | ------------------------------ |
| BSR          | 베스트셀러 순위            | Product Details 섹션           |
| Kindle $     | Kindle 전자책 가격         | 우측, 형식 아래                |
| Paperback $  | 페이퍼백 가격              | 우측, 형식 아래                |
| Hardcover $  | 하드커버 가격              | 우측, 형식 아래                |
| Reviews      | 총 리뷰 수                | 상단 별점 근처                 |
| Rating       | 평균 별점 (예: 4.6)       | 페이지 상단 근처               |
| Pages        | 페이지 수                  | Product Details → Print length |
| KU           | Kindle Unlimited 이용 가능 | "Read for Free" 배지 확인      |
| Top Category | 최고 카테고리 순위         | BSR 섹션, 가장 낮은 번호       |

## 상세 안내

### BSR (베스트셀러 순위) 찾기

1. **Product Details** 섹션까지 스크롤 (책 설명 아래)
2. **Best Sellers Rank** 찾기
3. 다음과 같이 보일 것: `#12,847 in Kindle Store`
4. 전체 번호 기록 (카테고리별 순위는 일단 무시)
5. 여러 형식이 표시되면 Kindle 순위 사용

**BSR 의미:**

- 10,000 미만 = 강한 판매
- 10,000–50,000 = 견실한 판매
- 50,000–100,000 = 보통 판매
- 100,000 초과 = 느린 판매

### 가격 찾기

1. 상품 페이지 **우측** 보기
2. 형식 옵션이 보일 것: Kindle, Paperback, Hardcover, Audiobook
3. 각 형식 클릭하여 가격 확인
4. 최소한 Kindle과 Paperback 기록
5. Kindle Unlimited에서 "FREE"로 표시되는 형식이 있는지 확인

### 리뷰 수와 평점 찾기

1. **페이지 상단** 근처, 제목 아래
2. 별점과 숫자가 보일 것: ⭐⭐⭐⭐☆ 4.3 out of 5 stars · 2,847 ratings
3. **Rating** = 5점 만점 숫자 (예: 4.3)
4. **Reviews** = 총 수 (예: 2,847)

### 페이지 수 찾기

1. **Product Details** 섹션까지 스크롤
2. **Print length** 또는 **Pages** 찾기
3. 숫자 기록

### Kindle Unlimited 상태 확인

다음 지표 중 하나를 찾기:

- "Read for Free" 버튼
- 가격 근처 "Kindle Unlimited" 배지
- "Kindle Unlimited" 언급과 함께 "$0.00"
- "Free with Kindle Unlimited membership"

기록: **Y** (KU에 있음) 또는 **N** (KU에 없음)

### 상위 카테고리 찾기

1. **BSR 섹션**에서 카테고리 순위가 보일 것
2. 예시: `#1 in Personal Productivity` / `#3 in Study Skills`
3. 책이 가장 높은 순위(가장 낮은 번호)인 카테고리 기록
4. 이것이 책이 가장 경쟁력 있는 곳을 나타냄

## 팁

- **새 탭에서 열기**: 더 빠른 데이터 입력을 위해 모든 경쟁자 URL을 별도 탭에서 열기
- **Kindle 페이지 사용**: BSR이 Kindle 에디션 페이지에서 종종 더 명확
- **오디오북 무시**: Kindle과 인쇄 형식에 집중
- **이상치 기록**: 비정상적인 것이 보이면 (예: 잘 알려지지 않은 책의 BSR이 47) 메모

## 소요 시간 추정

5-8권은 보통 완료하는 데 10-15분 소요.
