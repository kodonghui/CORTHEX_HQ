# 리서치 공백: [책 제목]

**생성일:** [날짜]
**아키텍처 버전:** [v#]
**상태:** Active

---

## 이 문서 사용 방법

각 공백에는 딥 리서치용 즉시 사용 가능한 프롬프트가 포함되어 있습니다. 프롬프트를 Claude, ChatGPT, Perplexity 또는 기타 리서치 도구에 복사하세요. 결과를 해당 섹션 블루프린트의 챕터 콘텐츠 노트에 붙여넣으세요.

**우선순위 수준:**

- **P1 (집필 차단):** 이것 없이는 챕터를 쓸 수 없음
- **P2 (논증 강화):** 없어도 챕터가 되지만 약해짐
- **P3 (있으면 좋음):** 풍부하게 하지만 필수는 아님

**상태 옵션:**

- Not Started
- In Progress
- Complete
- Incorporated (결과가 블루프린트에 추가됨)

---

## 요약

| 공백 ID | 우선순위 | 영향    | 설명    | 상태        |
| ------- | -------- | ------- | ------- | ----------- |
| 1.1     | P1       | Ch 3, 4 | [요약] | Not Started |
| 1.2     | P2       | Ch 5    | [요약] | Not Started |
| ...     | ...      | ...     | ...     | ...         |

---

## 섹션별 공백

---

### 섹션 1: [섹션 제목]

#### 공백 1.1: [공백 제목]

**우선순위:** P1 / P2 / P3
**영향:** 챕터 [X, Y]
**필요한 것:** [무엇이 빠져 있고 왜 중요한지 간략한 설명]

**리서치 프롬프트:**

```
BOOK CONTEXT:
Title: [책 제목]
Subtitle: [책 부제]
Core Thesis: [책의 중심 주장]
Target Reader: [그들이 누구인지, 시작 지점, 원하는 것]

THE ARGUMENT I'M BUILDING:
[영향받는 챕터에서 만들고 있는 구체적 주장이나 논증을 설명. 챕터의 목적은? 독자를 무엇에 대해 설득하려 하는가?]

THE GAP:
[무엇이 빠져 있는가? 무엇이 필요하지만 없는가? 이것이 논증에 왜 중요한지 구체적으로.]

WHAT I NEED:
1. [구체적 요청—증거, 데이터, 예시, 전문가 의견]
2. [구체적 요청]
3. [구체적 요청]
4. 내 입장에 대한 가장 강력한 반론이나 복잡한 사항
5. 내가 알아야 할 대안적 관점

FORMAT REQUESTED:
For each finding, provide:
- Source (author, title, year, publication)
- Key finding in 2-3 sentences
- One quotable line if available
- How it supports or complicates my argument
- Confidence level (established consensus / emerging / contested)

DEPTH: [P1 = go deep, this is central / P2 = solid coverage / P3 = quick scan]
```

**상태:** Not Started
**결과:** [리서치 후 작성]

---

#### 공백 1.2: [공백 제목]

**우선순위:** P1 / P2 / P3
**영향:** 챕터 [X]
**필요한 것:** [설명]

**리서치 프롬프트:**

```
BOOK CONTEXT:
Title: [...]
Subtitle: [...]
Core Thesis: [...]
Target Reader: [...]

THE ARGUMENT I'M BUILDING:
[...]

THE GAP:
[...]

WHAT I NEED:
1. [...]
2. [...]
3. [...]
4. Strongest counterarguments or complications
5. Alternative perspectives

FORMAT REQUESTED:
[...]

DEPTH: [...]
```

**상태:** Not Started
**결과:** [작성 예정]

---

### 섹션 2: [섹션 제목]

#### 공백 2.1: [공백 제목]

**우선순위:** [...]
**영향:** 챕터 [...]
**필요한 것:** [...]

**리서치 프롬프트:**

```
[...]
```

**상태:** [...]
**결과:** [...]

---

[모든 섹션과 공백에 대해 계속...]

---

## 횡단적 공백

_여러 섹션 또는 책 전체에 영향을 미치는 공백:_

#### 공백 X.1: [공백 제목]

**우선순위:** [...]
**영향:** [여러 섹션/챕터]
**필요한 것:** [...]

**리서치 프롬프트:**

```
[...]
```

**상태:** [...]
**결과:** [...]

---

## 완료 체크리스트

- [ ] 모든 P1 공백 리서치 및 반영 완료
- [ ] 모든 P2 공백 리서치 또는 의식적으로 보류
- [ ] P3 공백은 시간이 허용하는 대로 처리
- [ ] 결과가 섹션 블루프린트에 통합됨
- [ ] 리서치 중 발견된 새로운 공백이 이 문서에 추가됨

---

## 리서치 로그

| 날짜   | 공백 ID | 작업             | 노트                        |
| ------ | ------- | ---------------- | --------------------------- |
| [날짜] | [ID]    | 리서치 시작      | [노트]                      |
| [날짜] | [ID]    | 완료             | [핵심 결과 요약]            |
| [날짜] | [ID]    | 반영             | [Ch X 블루프린트에 추가]    |
