---
description: GitHub 이슈를 먼저 생성한 후, 기능 브랜치에서 솔루션을 구현하고 철저히 테스트한 다음 머지하는 방식으로 버그 수정 과정을 체계화합니다.
author: danielscholl
author-url: https://github.com/danielscholl
version: 1.0.0
---

버그 이해하기: $ARG

시작하기 전:
- GITHUB: 짧고 설명적인 제목으로 이슈를 생성합니다.
- GIT: 브랜치를 생성하고 전환합니다.

버그 수정하기

완료 후:
- GIT: 설명적인 메시지와 함께 커밋합니다.
- GIT: 브랜치를 원격 저장소에 푸시합니다.
- GITHUB: PR을 생성하고 이슈를 연결합니다.
